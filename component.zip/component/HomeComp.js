import React, { Component } from 'react'
import BodyComp from './BodyComp'

class HomeComp extends Component {
    render() {
        return (
            <div>
                <BodyComp/>
                
            </div>
        )
    }
}

export default HomeComp
