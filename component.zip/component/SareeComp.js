import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './cloths.css'


const Saree = () => {
  return (
    <div className='container backgroundphoto'>
       <div className='row m-5'>

       <div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
      <img
        src="https://rukminim2.flixcart.com/image/832/832/xif0q/sari/8/k/n/free-brasosari2-0-lorofy-unstitched-original-imagnyg2gqzqmfga.jpeg?q=70"
        className="card-img-top m-2"
        alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
      />
        <h6 className="card-title">₹699</h6>
       <p className="card-text">    FLIP SAREE</p>
     </div>
     <div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
      <img
        src="https://rukminim2.flixcart.com/image/832/832/xif0q/sari/3/l/q/-original-imagu22aykxzanyf.jpeg?q=70"
        className="card-img-top m-2"
        alt="Profile"style={{ width: '14rem' ,height:'18rem'}}
      />
        <h6 className="card-title">₹459</h6>
       <p className="card-text">COTTON SAREE</p>
     </div>


     <div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
      <img
        src="https://rukminim2.flixcart.com/image/832/832/xif0q/sari/b/1/4/free-lycra-blue-wish-unstitched-original-imagusq3h7whrnkk.jpeg?q=70"
        className="card-img-top m-2"
        alt="Profile"style={{ width: '14rem' ,height:'18rem'}}
      />
        <h6 className="card-title">₹599</h6>
       <p className="card-text">Self design Net Saree</p>
     </div>
      
     <div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
      <img
        src="https://rukminim2.flixcart.com/image/832/832/kzrbiq80/sari/j/4/d/free-mk-zal-cosbila-fashion-unstitched-original-imagbpgmfvx7cehu.jpeg?q=70"
        className="card-img-top m-2"
        alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
      />
        <h6 className="card-title">₹1009</h6>
       <p className="card-text">KANJI PATTU</p>
     </div>

     <div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
      <img
        src="https://rukminim2.flixcart.com/image/832/832/xif0q/sari/m/o/q/free-33-gold-purple-vf-vbhp-fashion-unstitched-original-imagu2nbhrk4j7pw.jpeg?q=70"
        className="card-img-top m-2"
        alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
      />
        <h6 className="card-title">₹569</h6>
       <p className="card-text">SILK SAREE</p>
     </div>

     <div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
      <img
        src="https://rukminim2.flixcart.com/image/832/832/kmjhw280/sari/f/6/o/free-karishma-gold-pink7-silknest-unstitched-original-imagfffd4def7syt.jpeg?q=70"
        className="card-img-top m-2"
        alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
      />
        <h6 className="card-title">₹989</h6>
       <p className="card-text">BANARAS PATTU</p>
     </div>

     

     



    

    

       <div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
      <img
        src="https://rukminim2.flixcart.com/image/832/832/xif0q/sari/x/v/t/free-37995-mirchi-fashion-unstitched-original-imagufkb4nhy7rf7.jpeg?q=70"
        className="card-img-top m-2"
        alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
      />
        <h6 className="card-title">₹599</h6>
       <p className="card-text"> NET SAREE</p>
     </div>


     <div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
      <img
        src="https://rukminim2.flixcart.com/image/832/832/kppt47k0/sari/t/o/v/free-awesome-maroon-villagius-unstitched-original-imag3vt2rwjssrbh.jpeg?q=70"
        className="card-img-top m-2"
        alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
      />
        <h6 className="card-title">₹699</h6>
       <p className="card-text"> HALF SAREE</p>
     </div>
      
     <div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
      <img
        src="https://rukminim2.flixcart.com/image/832/832/xif0q/sari/0/5/f/free-nc166-green-topjec-unstitched-original-imagsc2qudex6gw6.jpeg?q=70"
        className="card-img-top m-2"
        alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
      />
        <h6 className="card-title">₹999</h6>
       <p className="card-text">AARANI PATTU</p>
     </div>

     <div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
      <img
        src="https://rukminim2.flixcart.com/image/832/832/xif0q/shopsy-sari/c/m/n/free-nc161-white-copper-shopsy-leosagi-unstitched-original-imaghkujyvhhw92k.jpeg?q=70"
        className="card-img-top m-2"
        alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
      />
        <h6 className="card-title">₹799</h6>
       <p className="card-text">Design Net Saree</p>
     </div>

     <div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
      <img
        src="https://rukminim2.flixcart.com/image/832/832/xif0q/sari/z/p/x/free-2786s106r-satrani-unstitched-original-imagmvbjdavdf8jc.jpeg?q=70"
        className="card-img-top m-2"
        alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
      />
        <h6 className="card-title">₹399</h6>
       <p className="card-text"> Net Saree</p>
     </div>

     <div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
      <img
        src="https://rukminim2.flixcart.com/image/832/832/xif0q/sari/8/q/e/free-aalia-yourwish-unstitched-original-imagrzj7pje8svxg.jpeg?q=70"
        className="card-img-top m-2"
        alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
      />
        <h6 className="card-title">₹799</h6>
       <p className="card-text">SILK SAREE</p>
     </div>

     




<div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
<img
 src="https://rukminim2.flixcart.com/image/832/832/xif0q/sari/j/m/w/free-daily-wear-saree-print-saree-saree-new-2023-simple-chiffon-original-imagsfw3ebzxfg85.jpeg?q=70"
 className="card-img-top m-2"
 alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
/>
 <h6 className="card-title">₹599</h6>
<p className="card-text">PATTU </p>
</div>


<div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
<img
 src="https://rukminim2.flixcart.com/image/832/832/ky1vl3k0/sari/e/g/3/free-awesome-black-villagius-unstitched-original-imagadavr5pk3qmf.jpeg?q=70"
 className="card-img-top m-2"
 alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
/>
 <h6 className="card-title">₹499</h6>
<p className="card-text">POLYSTER SAREE</p>
</div>

<div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
<img
 src="https://rukminim2.flixcart.com/image/832/832/xif0q/sari/4/r/7/-original-imaguzbkgpahqvyt.jpeg?q=70"
 className="card-img-top m-2"
 alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
/>
 <h6 className="card-title">₹499</h6>
<p className="card-text">COTTON SAREE</p>
</div>

<div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
<img
 src="https://rukminim2.flixcart.com/image/832/832/xif0q/sari/t/y/l/free-20686-mirchi-fashion-unstitched-original-imagufkzggfg69fn.jpeg?q=70"
 className="card-img-top m-2"
 alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
/>
 <h6 className="card-title">₹875</h6>
<p className="card-text">Self design Net Saree</p>
</div>

<div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
<img
 src="https://rukminim2.flixcart.com/image/832/832/l2qhjm80/sari/p/j/z/free-samarth-pink-shaligraam-unstitched-original-imageyguq37rjdzj.jpeg?q=70"
 className="card-img-top m-2"
 alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
/>
 <h6 className="card-title">₹795</h6>
<p className="card-text">FLIP SAREE</p>
</div>

<div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
<img
 src="https://rukminim2.flixcart.com/image/832/832/xif0q/sari/5/j/c/free-soft-silk-saree-saree-2023-new-model-design-saree-silk-sari-original-imagz7yjhnfhppcj.jpeg?q=70"
 className="card-img-top m-2"
 alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
/>
 <h6 className="card-title">₹599</h6>
<p className="card-text">Self design Net Saree</p>
</div>






<div className="card m-5 col-3" style={{ width: '16rem' ,height:'22rem'}}>
<img
 src="https://rukminim2.flixcart.com/image/832/832/xif0q/sari/3/m/j/free-kfs-28-grey-khadki-unstitched-original-imagzujm6kwyxdfz.jpeg?q=70"
 className="card-img-top m-2"
 alt="Profile" style={{ width: '14rem' ,height:'18rem'}}
/>
 <h6 className="card-title">₹799</h6>
<p className="card-text">Self design Saree</p>
</div>
</div> 



</div>

     
   
  );
};

export default Saree;
